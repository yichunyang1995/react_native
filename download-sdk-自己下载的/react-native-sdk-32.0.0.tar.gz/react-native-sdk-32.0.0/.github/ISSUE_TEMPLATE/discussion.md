---
name: 🗣 Start a Discussion
about: Use https://github.com/react-native-community/discussions-and-proposals to propose changes or discuss feature requests.
---

Please use https://github.com/react-native-community/discussions-and-proposals to propose changes or discuss feature requests.

We kindly ask that issues of this type are kept in that dedicated repo, to ensure bug reports and regressions are given the priority they require.

Maintainers may flag an issue for Stack Overflow or kindly ask you to move the discussion to https://github.com/react-native-community/discussions-and-proposals at their own discretion.

---

# For Discussion

<!-- Describe your issue in detail. -->

